# Notebooks

## Current research notebook

[`LithoAI_2_0_Research_Notebook.ipynb`](LithoAI_2_0_Research_Notebook.ipynb) is the current reference notebook. It contains the LithoAI 2.0 experiments, saved outputs and research discussion. Its saved copy has 63/63 code cells executed sequentially, with no saved Python exceptions.

## Earlier notebook copies

`lithoai_experiments.ipynb` is an earlier exploratory version retained for history. If `LithoAI_2_0_Audited_Cleaned (1).ipynb` is still present, it is a superseded upload copy; use the clearly named `LithoAI_2_0_Research_Notebook.ipynb` instead. These older files can be removed after the current notebook has been confirmed on GitHub, but their removal is not required to run the project.

Supporting material:
- [`results/README.md`](results/README.md): detailed experimental result tables.
- [`documentation/README.md`](documentation/README.md): methodology and reproducibility notes.
