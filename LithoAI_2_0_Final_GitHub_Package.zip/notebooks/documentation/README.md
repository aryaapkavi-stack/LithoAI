# Methodology and Reproducibility Notes

## Dataset and target

LithoAI 2.0 uses the UCI SECOM dataset (1,567 observations, 590 sensor features and 104 failure labels). Labels are mapped to pass = 0 and fail = 1. The dataset includes 1,534 unique timestamps, so repeated timestamps are kept within the same group for grouped validation. Three timestamp groups contain both labels; grouped splitting prevents cross-fold overlap but does not resolve these conflicting labels.

## Primary grouped model comparison

The primary model comparison uses five-fold `StratifiedGroupKFold` with timestamp groups, shuffling enabled and `random_state=42`.

- Logistic Regression: median imputation, variance filtering, standard scaling and class-balanced logistic regression (`max_iter=3000`).
- Random Forest: median imputation, variance filtering and 300 trees (`min_samples_leaf=2`, `class_weight="balanced_subsample"`, `random_state=42`).
- HistGradientBoosting: median imputation with empty features retained, variance filtering and 200 iterations (`learning_rate=0.05`, `max_leaf_nodes=15`, `l2_regularization=1.0`, `class_weight="balanced"`, `random_state=42`).

Average precision is used because failures are rare. Pooled out-of-fold AP and the arithmetic mean of fold AP are reported separately; they are not interchangeable.

## Nested threshold evaluation

Nested validation uses five outer grouped folds and four inner grouped folds (`random_state=42` outer; `random_state=123` inner). A threshold is selected from inner out-of-fold predictions to target at least 0.80 recall, then evaluated on the untouched outer fold. The recall target is not guaranteed on outer test observations.

## Additional missingness experiment

Five repetitions are run for each additional test-time masking level (0%, 5%, 10%, 20%, 30%). Masking is applied to values that were originally observed in each test fold; the training fold is not additionally masked. This is a simulation of inference-time sensor dropout, not a simulation of missingness during training.

## Temporal generalisation

Unique timestamps are sorted and divided into five chronological periods. Expanding-window training uses all periods before the test period. The model is evaluated on Periods 3, 4 and 5. These test periods contain 11, 11 and 17 failures, so their AP estimates have substantial uncertainty.

## Sensor distribution audit

For each expanding-window split, the audit compares train and test sensor medians, IQRs and missingness. The absolute median shift is scaled by the training IQR. Features with unavailable or non-positive training IQR are not assigned an infinite shift; they are excluded from that scaled statistic. Missingness changes are expressed in percentage points.

## Grouped permutation importance

Permutation importance uses five timestamp-grouped folds, 10 repeats per feature per fold, `random_state=42` and average precision scoring. Importance is descriptive and can be distributed across correlated sensors; it is not causal evidence.

## Software and reproducibility

The notebook uses Python, NumPy, Pandas, scikit-learn and Matplotlib, along with Python standard-library modules for dataset download and archive handling. Install the dependencies using the repository `requirements.txt`. Run the notebook from top to bottom in a fresh environment with internet access. A scikit-learn warning may appear in an early temporal fold when some sensors have no observed training values; the model run completed despite this warning. The notebook's saved outputs were produced in a fresh, sequential run (63/63 code cells, no saved Python exceptions).

## Scope and limitations

SECOM is a general semiconductor manufacturing dataset. It does not establish that the recorded measurements belong specifically to lithography. This study has not been validated on a second dataset, separate fabrication facility or production line; it is an experimental research prototype.
